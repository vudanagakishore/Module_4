package com.cg.sample;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sample1 
{
	public static void main(String args [])
	{
	
		File file = new File("C:/Users/savuda/Downloads/BDD_Files/chromedriver/chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getPath());
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
		
		driver.manage().window().maximize();
		//driver.manage().window().fullscreen();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.findElement(By.name("q")).sendKeys("India");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.findElement(By.name("btnK")).submit();       
		
		System.out.println(("Page Title is: ") + driver.getTitle());
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		driver.get("https://www.bing.com/");
		
		driver.manage().window().maximize();
		//driver.manage().window().fullscreen();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		//driver.findElement(By.name("q")).sendKeys("Sun");
		WebElement we=driver.findElement(By.name("q"));
		we.sendKeys("Sun");
		we.sendKeys(Keys.ENTER);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		//driver.findElement(By.name("go")).submit();   
		
		System.out.println(("Page Title is: ") + driver.getTitle());
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
		
	/*	driver.get("https://www.google.com/");
		
		
		driver.manage().window().maximize();
		//driver.manage().window().fullscreen();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.findElement(By.name("q")).sendKeys("Moon");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.findElement(By.name("btnK")).submit();       
		
		System.out.println(("Page Title is: ") + driver.getTitle());
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://www.bing.com/");
		
		driver.manage().window().maximize();
		//driver.manage().window().fullscreen();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.findElement(By.name("q")).sendKeys("Earth");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.findElement(By.name("btnK")).submit();;       
		
		System.out.println(("Page Title is: ") + driver.getTitle());
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		driver.close();
		
		driver.quit();
		
		
	}
}





File file = new File("C:/Users/savuda/Downloads/BDD_Files/chromedriver/chromedriver.exe");
System.setProperty("webdriver.chrome.driver", file.getPath());
WebDriver driver = new ChromeDriver();
driver.get("https://www.google.com/");


driver.manage().window().maximize();
//driver.manage().window().fullscreen();
driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
driver.findElement(By.name("q")).sendKeys("India");

try {
	Thread.sleep(2000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

driver.findElement(By.name("btnK")).submit();       

System.out.println(("Page Title is: ") + driver.getTitle());

try {
	Thread.sleep(5000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

driver.close();

driver.quit();

*/
	